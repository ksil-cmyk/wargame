var express  = require("express");
var router   = express.Router();
var Post     = require("../models/Post");
var util     = require("../util");

// Index
router.get("/", function(req, res){
  var page = Math.max(1, req.query.page);
  var limit = 10;
  Post.count({}, function(err, count) {
    if(err) return res.json({success:false, message:err});
    var skip = (page-1)*limit;
    var maxPage = Math.ceil(count/limit);

  var Counter = require('../models/Counter');
  var vistorCounter = null;
  Counter.findOne({name:"vistors"}, function (err,counter) {
    if(!err) vistorCounter = counter;
  });

  Post.find({}).populate("author").sort("-createdAt").skip(skip).limit(limit).exec(function(err, posts){
      if(err) return res.json(err);
      res.render("posts/index", {posts:posts, counter:vistorCounter, page:page, maxPage:maxPage});
    });
  });
});

// New
router.get("/new", util.isLoggedin, function(req, res){
  var post = req.flash("post")[0] || {};
  var errors = req.flash("errors")[0] || {};
  res.render("posts/new", { post:post, errors:errors });
});

// create
router.post("/", util.isLoggedin, function(req, res){
  console.log(req.user._id);
  req.body.author = req.user._id;
  Post.create(req.body, function(err, post){
    if(err){
      req.flash("post", req.body);
      req.flash("errors", util.parseError(err));
      return res.redirect("/posts/new");
    }
    console.log(req.body);
    res.redirect("/posts");
  });
});

// show
router.get("/:id", function(req, res){
  Post.findById(req.params.id)
  .populate(['author', 'comments.author'])
  .exec(function(err, post){
    if(err) return res.json(err);
    res.render("posts/show", {post:post, page:req.query.page, user:req.user});
  });
});

// edit
router.get("/:id/edit", util.isLoggedin, checkPermission, function(req, res){
  var post = req.flash("post")[0];
  var errors = req.flash("errors")[0] || {};
  if(!post){
    Post.findOne({_id:req.params.id}, function(err, post){
      if(err) return res.json(err);
      res.render("posts/edit", { post:post, errors:errors });
    });
  } else {
    post._id = req.params.id;
    res.render("posts/edit", { post:post, errors:errors });
  }
});

// update
router.put("/:id", util.isLoggedin, checkPermission, function(req, res){
  req.body.updatedAt = Date.now();
  Post.findOneAndUpdate({_id:req.params.id}, req.body, {runValidators:true}, function(err, post){
    if(err){
      req.flash("post", req.body);
      req.flash("errors", util.parseError(err));
      return res.redirect("/posts/"+req.params.id+"/edit");
    }
    res.redirect("/posts/"+req.params.id);
  });
});

// destroy
router.delete("/:id", util.isLoggedin, checkPermission, function(req, res){
  Post.remove({_id:req.params.id}, function(err){
    if(err) return res.json(err);
    res.redirect("/posts");
  });
});


router.post('/:id/comments', function(req,res){
  var newComment = req.body.comment;
  newComment.author = req.user._id;
  Post.update({_id:req.params.id},{$push:{comments:newComment}},function(err,post){
    if(err) return res.json({success:false, message:err});
    res.redirect('/posts/'+req.params.id+"?"+req._parsedUrl.query);
  });

  // Post.find({}).populate("author").sort("-createdAt").exec(function(err, posts){
  //     if(err) return res.json(err);
  //     res.redirect('/posts/'+req.user._id);
  //   });
}); //create a comment

router.delete('/:postId/comments/:commentId', function(req,res){
  Post.update({_id:req.params.postId},{$pull:{comments:{_id:req.params.commentId}}},
    function(err,post){
      if(err) return res.json({success:false, message:err});
      res.redirect('/posts/'+req.params.postId+"?"+
                   req._parsedUrl.query.replace(/_method=(.*?)(&|$)/ig,""));
  });
}); //destroy a comment

module.exports = router;

// private functions
function checkPermission(req, res, next){
  Post.findOne({_id:req.params.id}, function(err, post){
    if(err) return res.json(err);
    if(post.author != req.user.id) return util.noPermission(req, res);

    next();
  });
}
