var express = require("express");
var router  = express.Router();
var Quiz  = require("../models/Quiz");
var util    = require("../util");
var mongoose = require("mongoose");
var User = require("../models/User");
var ejs = require('ejs');
var async = require('async');
var moment = require('moment');

// DB setting
mongoose.connect(process.env.MONGO_DB, {useNewUrlParser:true});
mongoose.set('useCreateIndex', true)
var db = mongoose.connection;
db.once("open", function(){
  console.log("DB connected");
});
db.on("error", function(err){
  console.log("DB ERROR : ", err);
});

// Redis setting
var redis = require('redis');
var client = redis.createClient("6379", "127.0.0.1");
client.on('connect', function() {
  console.log('redis connected');
});

client.select(7);

// Router
router.get("/", util.isLoggedin, function(req, res){
  res.render("challenges/index");
});

router.get("/quiz", util.isLoggedin, function(req, res){
  User.findOne({username:req.user.username}, function(err, user){
    if(err) return res.json(err);
    res.render("challenges/quiz", {user:user});
  });
});

router.post("/quiz", function(req, res, next) {
  console.log("/quiz 호출됨");

  var paramQuestion = 'already got';
  var paramAnswer = req.param('answer');
  var userId = req.user._id;
  console.log(req.user);
  console.log(req.user.username);
  console.log(req.user._id);

  if(db) {
    authUser(db, paramQuestion, paramAnswer, function(err, docs) {
      if(err) {throw err;}

      if(docs) {
        var User = db.collection('users');
        User.updateOne({"_id":userId}, {$inc: {point: 89}});

        var id = req.user.id;
        var username = req.user.username;
        var email = req.user.email;
        var score = req.body.score;
        var obj = {
          id : id,
          username : username,
          email : email,
          score : score
        };

        client.hset(id, "username", obj.username);
        client.hset(id, "email", obj.email);
        client.hincrby(id, "score", obj.score);

        var board = "leaderboard";
        var score = 89;
        var start = 0;
        var end = 5;

        client.zincrby(board, parseInt(score), obj.id);

        client.ZREVRANGE(board, start, end, function(err, members){
          console.log('members', members);
          var scores = [];
          async.each(members, function(item, done){
            client.hgetall(item, function(err, doc){
              console.log('doc', doc);
              scores.push(doc);
              done();
            });
          }, function(err) {
            if(err) console.error('err', err);
            console.log('scores', scores);
            res.render('challenges/rank', {scores:scores});
          });
        });
        console.dir(docs);
        var question = docs[0].question;

      } else {
        res.render('challenges/quiz_fail');
      }
    });
  }
});

router.get("/quiz2", util.isLoggedin, function(req, res){
  res.render("challenges/quiz2");
});

router.get("/quiz3", util.isLoggedin, function(req, res){
  res.render("challenges/quiz3");
});

router.get("/quiz4", util.isLoggedin, function(req, res){
  User.findOne({username:req.user.username}, function(err, user){
    if(err) return res.json(err);
    res.render("challenges/quiz4", {user:user});
  });
});

router.get("/quiz4/wtf_code", util.isLoggedin, function(req, res){
  res.render("challenges/quiz4/wtf_code");
});

// 2번 시연
router.post("/quiz4", function(req, res) {
  console.log("/quiz4 호출됨");

  var paramQuestion = 'wtf code';
  var paramAnswer = req.param('answer');
  var userId = req.user._id;
  console.log(req.user);
  console.log(req.user.username);
  console.log(req.user._id);

  if(db) {
    authUser4(db, paramQuestion, paramAnswer, function(err, docs) {
      if(err) {throw err;}

      if(docs) {
        var User = db.collection('users');
        User.updateOne({"_id":userId}, {$inc: {point: 166}});

        var id = req.user.id;
        var username = req.user.username;
        var email = req.user.email;
        var score = req.body.score;
        var obj = {
          id : id,
          username : username,
          email : email,
          score : score
        };

        client.hset(id, "username", obj.username);
        client.hset(id, "email", obj.email);
        client.hincrby(id, "score", obj.score);

        var board = "leaderboard";
        var score = 166;
        var start = 0;
        var end = 9;

        client.zincrby(board, parseInt(score), obj.id);

        client.ZREVRANGE(board, start, end, function(err, members){
          console.log('members', members);
          var scores = [];
          async.each(members, function(item, done){
            client.hgetall(item, function(err, doc){
              console.log('doc', doc);
              scores.push(doc);
              done();
            });
          }, function(err) {
            if(err) console.error('err', err);
            console.log('scores', scores);
            res.render('challenges/rank', {scores:scores});
          });
        });
        console.dir(docs);
        var question = docs[0].question;

      } else {
        res.render('challenges/quiz_fail4');
      }
    });
  }
});

router.get("/quiz5", util.isLoggedin, function(req, res){
  res.render("challenges/quiz5");
});

router.get("/quiz6", util.isLoggedin, function(req, res){
  res.render("challenges/quiz6");
});

router.get("/quiz7", util.isLoggedin, function(req, res){
  res.render("challenges/quiz7");
});

router.get("/quiz8", util.isLoggedin, function(req, res){
  res.render("challenges/quiz8");
});

router.get("/quiz9", util.isLoggedin, function(req, res){
  res.render("challenges/quiz9");
});

router.get("/quiz10", util.isLoggedin, function(req, res){
  User.findOne({username:req.user.username}, function(err, user){
    if(err) return res.json(err);
    res.render("challenges/quiz10", {user:user});
  });
});

router.get("/quiz10/EASY_CrackMe", util.isLoggedin, function(req, res){
  res.render("challenges/quiz10/EASY_CrackMe");
});

// 3번 시연
router.post("/quiz10", function(req, res) {
  console.log("/quiz10 호출됨");

  var paramQuestion = 'EASY_CrackMe';
  var paramAnswer = req.param('answer');
  var userId = req.user._id;
  console.log(req.user);
  console.log(req.user.username);
  console.log(req.user._id);

  if(db) {
    authUser10(db, paramQuestion, paramAnswer, function(err, docs) {
      if(err) {throw err;}

      if(docs) {
        var User = db.collection('users');
        User.updateOne({"_id":userId}, {$inc: {point: 311}});

        var id = req.user.id;
        var username = req.user.username;
        var email = req.user.email;
        var score = req.body.score;
        var obj = {
          id : id,
          username : username,
          email : email,
          score : score
        };

        client.hset(id, "username", obj.username);
        client.hset(id, "email", obj.email);
        client.hincrby(id, "score", obj.score);

        var board = "leaderboard";
        var score = 311;
        var start = 0;
        var end = 5;

        client.zincrby(board, parseInt(score), obj.id);

        client.ZREVRANGE(board, start, end, function(err, members){
          console.log('members', members);
          var scores = [];
          async.each(members, function(item, done){
            client.hgetall(item, function(err, doc){
              console.log('doc', doc);
              scores.push(doc);
              done();
            });
          }, function(err) {
            if(err) console.error('err', err);
            console.log('scores', scores);
            res.render('challenges/rank', {scores:scores});
          });
        });
        console.dir(docs);
        var question = docs[0].question;

      } else {
        res.render('challenges/quiz_fail10');
      }
    });
  }
});

router.get("/quiz11", util.isLoggedin, function(req, res){
  res.render("challenges/quiz11");
});

router.get("/quiz12", util.isLoggedin, function(req, res){
  res.render("challenges/quiz12");
});

router.get("/quiz13", util.isLoggedin, function(req, res){
  res.render("challenges/quiz13");
});

router.get("/quiz14", util.isLoggedin, function(req, res){
  res.render("challenges/quiz14");
});

router.get("/quiz15", util.isLoggedin, function(req, res){
  res.render("challenges/quiz15");
});

router.get("/quiz16", util.isLoggedin, function(req, res){
  res.render("challenges/quiz16");
});

router.get("/quiz17", util.isLoggedin, function(req, res){
  res.render("challenges/quiz17");
});

router.get("/quiz18", util.isLoggedin, function(req, res){
  res.render("challenges/quiz18");
});

router.get("/quiz19", util.isLoggedin, function(req, res){
  res.render("challenges/quiz19");
});

router.get("/quiz20", util.isLoggedin, function(req, res){
  res.render("challenges/quiz20");
});

router.get("/quiz21", util.isLoggedin, function(req, res){
  res.render("challenges/quiz21");
});

router.get("/quiz22", util.isLoggedin, function(req, res){
  res.render("challenges/quiz22");
});

router.get("/quiz23", util.isLoggedin, function(req, res){
  res.render("challenges/quiz23");
});

router.get("/quiz24", util.isLoggedin, function(req, res){
  res.render("challenges/quiz24");
});

router.get("/quiz25", util.isLoggedin, function(req, res){
  res.render("challenges/quiz25");
});

router.get("/quiz26", util.isLoggedin, function(req, res){
  res.render("challenges/quiz26");
});

router.get("/quiz27", util.isLoggedin, function(req, res){
  res.render("challenges/quiz27");
});

router.get("/quiz28", util.isLoggedin, function(req, res){
  res.render("challenges/quiz28");
});

router.get("/quiz29", util.isLoggedin, function(req, res){
  res.render("challenges/quiz29");
});

router.get("/quiz30", util.isLoggedin, function(req, res){
  res.render("challenges/quiz30");
});

router.get("/quiz31", util.isLoggedin, function(req, res){
  res.render("challenges/quiz31");
});

router.get("/quiz32", util.isLoggedin, function(req, res){
  res.render("challenges/quiz32");
});

router.get("/quiz33", util.isLoggedin, function(req, res){
  res.render("challenges/quiz33");
});

router.get("/quiz34", util.isLoggedin, function(req, res){
  res.render("challenges/quiz34");
});

router.get("/quiz35", util.isLoggedin, function(req, res){
  res.render("challenges/quiz35");
});

router.get("/quiz36", util.isLoggedin, function(req, res){
  res.render("challenges/quiz36");
});

// 1번 시연
router.get("/quiz/already_got", util.isLoggedin, function(req, res){
  res.render("challenges/quiz/already_got");
});

router.get("/quiz2/qr_code_puzzle", util.isLoggedin, function(req, res){
  res.render("challenges/quiz2/qr_code_puzzle");
});

router.get("/quiz18/keypad_crackme", util.isLoggedin, function(req, res){
  res.render("challenges/quiz18/keypad_crackme");
});

var authUser = function(db, question, answer, callback) {
  console.log('authUser 호출됨');

  var Quiz = db.collection('quiz');

  Quiz.find({"question":'already got', "answer":answer}).toArray(function(err, docs) {
    if(err) {
      callback(err, null);
      return;
    }

    if(docs.length > 0) {
      console.log('문제 already_got, 정답 [%s]이 일치하는 사용자 찾음', answer);
      callback(null, docs);
    } else {
      console.log('정답이 틀렸습니다.');
      callback(null, null);
    }
  });
}

var authUser4 = function(db, question, answer, callback) {
  console.log('authUser4 호출됨');

  var Quiz = db.collection('quiz');

  Quiz.find({"question":'wtf code', "answer":answer}).toArray(function(err, docs) {
    if(err) {
      callback(err, null);
      return;
    }

    if(docs.length > 0) {
      console.log('문제 wtf code, 정답 [%s]이 일치하는 사용자 찾음', answer);
      callback(null, docs);
    } else {
      console.log('정답이 틀렸습니다.');
      callback(null, null);
    }
  });
}

var authUser10 = function(db, question, answer, callback) {
  console.log('authUser10 호출됨');

  var Quiz = db.collection('quiz');

  Quiz.find({"question":'EASY_CrackMe', "answer":answer}).toArray(function(err, docs) {
    if(err) {
      callback(err, null);
      return;
    }

    if(docs.length > 0) {
      console.log('문제 EASY_CrackMe, 정답 [%s]이 일치하는 사용자 찾음', answer);
      callback(null, docs);
    } else {
      console.log('정답이 틀렸습니다.');
      callback(null, null);
    }
  });
}
module.exports = router;
