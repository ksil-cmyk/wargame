var express = require("express");
var router  = express.Router();
var passport= require("../config/passport");
var async = require('async');
var moment = require('moment');

// Redis setting
var redis = require('redis');
var client = redis.createClient("6379", "127.0.0.1");
client.on('connect', function() {
  console.log('redis connected');
});

client.select(7);

// Home
router.get("/", function(req, res){
  var board = "leaderboard";
  var start = 0;
  var end = 9;

  client.ZREVRANGE(board, start, end, function(err, members){
    console.log('members', members);
    var scores = [];
    async.each(members, function(item, done){
      client.hgetall(item, function(err, doc){
        console.log('doc', doc);
        scores.push(doc);
        done();
      });
    }, function(err) {
      if(err) console.error('err', err);
      console.log('scores', scores);
      res.render('home/welcome', {scores:scores});
    });
  });
});

router.get("/rank", function(req, res){
  var board = "leaderboard";
  var start = 0;
  var end = 5;

  client.ZREVRANGE(board, start, end, function(err, members){
    console.log('members', members);
    var scores = [];
    async.each(members, function(item, done){
      client.hgetall(item, function(err, doc){
        console.log('doc', doc);
        scores.push(doc);
        done();
      });
    }, function(err) {
      if(err) console.error('err', err);
      console.log('scores', scores);
      res.render('challenges/rank', {scores:scores});
    });
  });
});

router.get("/archive", function(req, res){
  res.render("archives/archive");
});

// Login
router.get("/login", function (req,res) {
  var username = req.flash("username")[0];
  var errors = req.flash("errors")[0] || {};
  res.render("home/login", {
    username:username,
    errors:errors
  });
});

// Post Login
router.post("/login",  function(req,res,next){
    var errors = {};
    var isValid = true;

    if(!req.body.username){
      isValid = false;
      errors.username = "Username is required!";
    }
    if(!req.body.password){
      isValid = false;
      errors.password = "Password is required!";
    }

    if(isValid){
      next();
    } else {
      req.flash("errors",errors);
      res.redirect("/login");
    }
  },
  passport.authenticate("local-login", {
    successRedirect : "/",
    failureRedirect : "/login"
  }
));

// Logout
router.get("/logout", function(req, res) {
  req.logout();
  res.redirect("/");
});

module.exports = router;
