var mongoose = require('mongoose');

var quizSchema = mongoose.Schema({
  question: {type:String},
  answer: {type:String},
  score: {type:Number}
});

var Quiz = mongoose.model('quiz', quizSchema);
module.exports = Quiz;
